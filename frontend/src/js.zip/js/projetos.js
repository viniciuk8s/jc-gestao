/* ============================================================
   projetos.js — Gestão de Projetos (Kanban)
   localStorage, arrastar-e-soltar entre colunas, filtros,
   envolvidos (funcionários cadastrados + terceiros), progresso e prazo.
   Cadastro/edição via modal dinâmico (JC.modal).
   ============================================================ */
'use strict';

(function () {
  if (!document.getElementById('kanban')) return;

  var KEY = 'jc_projetos';
  var STATUSES = ['planejamento', 'andamento', 'revisao', 'concluido'];
  var STATUS_LABEL = { planejamento: 'Planejamento', andamento: 'Em execução', revisao: 'Em revisão', concluido: 'Concluído' };
  var PRIO_LABEL = { alta: 'Alta', media: 'Média', baixa: 'Baixa' };

  var JC = window.JC;
  // Helpers compartilhados (ver utils.js)
  var esc = JC.esc, fmtDateBR = JC.fmtDateShort;   // projetos usa data curta (DD/MM)
  var initials = JC.initials, colorFor = JC.color;

  var state = {
    projs: load(),
    busca: '',
    setor: 'todos',
    prio: 'todos'
  };

  /* ---------- Persistência ---------- */
  function load() {
    try { var raw = localStorage.getItem(KEY); if (raw) return JSON.parse(raw); } catch (e) {}
    return seed();
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(state.projs)); } catch (e) {} }
  function seed() {
    var base = [
      { nome: 'Usina solar — Galpão Industrial', cliente: 'Indústria Norte', setor: 'Solar', status: 'andamento', prio: 'alta', entrega: '2026-06-20', progresso: 60, descricao: '', envolvidos: [{ nome: 'Carlos Lima', tipo: 'funcionario' }, { nome: 'Rafael Gomes', tipo: 'funcionario' }, { nome: 'Cooperativa Solar', tipo: 'terceiro' }] },
      { nome: 'Reforma elétrica — Mercado São José', cliente: 'Mercado São José', setor: 'Elétrica', status: 'revisao', prio: 'media', entrega: '2026-06-15', progresso: 85, descricao: '', envolvidos: [{ nome: 'João Pedro', tipo: 'funcionario' }, { nome: 'Maria Souza', tipo: 'funcionario' }] },
      { nome: 'Projeto fotovoltaico — Padaria', cliente: 'Padaria Pão Quente', setor: 'Solar', status: 'planejamento', prio: 'media', entrega: '', progresso: 15, descricao: '', envolvidos: [{ nome: 'Maria Souza', tipo: 'funcionario' }] },
      { nome: 'Quadro de distribuição — Aldeota', cliente: 'Residência Aldeota', setor: 'Elétrica', status: 'concluido', prio: 'baixa', entrega: '2026-06-05', progresso: 100, descricao: '', envolvidos: [{ nome: 'João Pedro', tipo: 'funcionario' }] },
      { nome: 'Proposta comercial — Condomínio', cliente: 'Cond. Vila Verde', setor: 'Comercial', status: 'planejamento', prio: 'alta', entrega: '2026-06-12', progresso: 30, descricao: '', envolvidos: [{ nome: 'Ana Beatriz', tipo: 'funcionario' }] }
    ];
    return base.map(function (p, i) { p.id = 'p' + (Date.now() + i); return p; });
  }

  /* ---------- Funcionários cadastrados (base de RH) ---------- */
  function getEmployees() {
    try {
      var raw = localStorage.getItem('jc_funcionarios');
      if (raw) {
        var arr = JSON.parse(raw);
        if (arr && arr.length) return arr.map(function (f) { return f.nome; });
      }
    } catch (e) {}
    return ['Maria Souza', 'Carlos Lima', 'João Pedro', 'Ana Beatriz', 'Rafael Gomes', 'Patrícia Nunes'];
  }

  /* ---------- Helpers ---------- */
  function isOverdue(p) {
    if (!p.entrega || p.status === 'concluido') return false;
    var hoje = new Date(); hoje.setHours(0, 0, 0, 0);
    return new Date(p.entrega + 'T00:00:00') < hoje;
  }

  function passesFilter(p) {
    var q = state.busca.toLowerCase();
    if (state.setor !== 'todos' && p.setor !== state.setor) return false;
    if (state.prio !== 'todos' && p.prio !== state.prio) return false;
    if (q && (p.nome + ' ' + (p.cliente || '')).toLowerCase().indexOf(q) === -1) return false;
    return true;
  }

  /* ---------- Render ---------- */
  function render() {
    STATUSES.forEach(function (st) {
      var col = document.getElementById('col-' + st);
      var cnt = document.getElementById('cnt-' + st);
      if (!col) return;
      var items = state.projs.filter(function (p) { return p.status === st && passesFilter(p); });
      if (cnt) cnt.textContent = items.length;
      col.innerHTML = items.length === 0 ? '<div class="kb-empty">Sem projetos</div>' : items.map(cardHTML).join('');
      bindCards(col);
    });
  }

  function avatarsHTML(envolvidos) {
    if (!envolvidos || !envolvidos.length) return '';
    var max = 4;
    var shown = envolvidos.slice(0, max);
    var rest = envolvidos.length - shown.length;
    var html = shown.map(function (e) {
      if (e.tipo === 'terceiro') {
        return '<span class="pj-av terceiro" title="' + esc(e.nome) + ' (terceiro)">' + esc(initials(e.nome)) + '</span>';
      }
      return '<span class="pj-av" style="background:' + colorFor(e.nome) + '" title="' + esc(e.nome) + '">' + esc(initials(e.nome)) + '</span>';
    }).join('');
    if (rest > 0) html += '<span class="pj-av more" title="mais ' + rest + '">+' + rest + '</span>';
    return '<div class="pj-avatars">' + html + '</div>';
  }

  function dueHTML(p) {
    if (!p.entrega) return '<span class="pj-due none"><i class="bi bi-calendar-x"></i> Sem prazo</span>';
    var over = isOverdue(p);
    var icon = over ? 'bi-exclamation-circle' : 'bi-calendar3';
    var txt = over ? 'Atrasado ' + fmtDateBR(p.entrega) : fmtDateBR(p.entrega);
    return '<span class="pj-due' + (over ? ' over' : '') + '"><i class="bi ' + icon + '"></i> ' + txt + '</span>';
  }

  function cardHTML(p) {
    var prog = Math.max(0, Math.min(100, Number(p.progresso || 0)));
    var done = p.status === 'concluido' ? ' done' : '';
    return '' +
    '<div class="kb-card prio-' + p.prio + done + '" draggable="true" data-id="' + p.id + '">' +
      '<div class="kb-card-head">' +
        '<div class="kb-card-title">' + esc(p.nome) + '</div>' +
        '<div class="kb-card-actions">' +
          '<button class="icon-btn pj-edit" data-id="' + p.id + '" aria-label="Editar"><i class="bi bi-pencil"></i></button>' +
          '<button class="icon-btn danger pj-del" data-id="' + p.id + '" aria-label="Excluir"><i class="bi bi-trash3"></i></button>' +
        '</div>' +
      '</div>' +
      (p.cliente ? '<div class="kb-card-client"><i class="bi bi-building"></i> ' + esc(p.cliente) + '</div>' : '') +
      '<span class="kb-tag">' + esc(p.setor) + '</span>' +
      '<div class="pj-prog">' +
        '<div class="pj-prog-meta"><span>Progresso</span><span>' + prog + '%</span></div>' +
        '<div class="pj-prog-track"><div class="pj-prog-bar" style="width:' + prog + '%"></div></div>' +
      '</div>' +
      '<div class="kb-card-foot">' +
        dueHTML(p) +
        avatarsHTML(p.envolvidos) +
      '</div>' +
    '</div>';
  }

  function bindCards(scope) {
    scope.querySelectorAll('.pj-edit').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var p = state.projs.find(function (x) { return x.id === b.dataset.id; });
        if (p) openForm(p);
      });
    });
    scope.querySelectorAll('.pj-del').forEach(function (b) {
      b.addEventListener('click', function (e) { e.stopPropagation(); removeProj(b.dataset.id); });
    });
    scope.querySelectorAll('.kb-card').forEach(function (card) {
      card.addEventListener('dragstart', function (e) {
        card.classList.add('dragging');
        e.dataTransfer.setData('text/plain', card.dataset.id);
        e.dataTransfer.effectAllowed = 'move';
      });
      card.addEventListener('dragend', function () { card.classList.remove('dragging'); });
    });
  }

  /* ---------- Drag & drop entre colunas ---------- */
  function initDnD() {
    STATUSES.forEach(function (st) {
      var col = document.getElementById('col-' + st);
      if (!col) return;
      col.addEventListener('dragover', function (e) { e.preventDefault(); col.classList.add('drop'); });
      col.addEventListener('dragleave', function (e) { if (!col.contains(e.relatedTarget)) col.classList.remove('drop'); });
      col.addEventListener('drop', function (e) {
        e.preventDefault();
        col.classList.remove('drop');
        var id = e.dataTransfer.getData('text/plain');
        var p = state.projs.find(function (x) { return x.id === id; });
        if (p && p.status !== st) {
          p.status = st;
          if (st === 'concluido') p.progresso = 100;
          save(); render();
        }
      });
    });
  }

  /* ---------- Excluir ---------- */
  function removeProj(id) {
    var p = state.projs.find(function (x) { return x.id === id; });
    if (!p) return;
    JC.confirm({ message: 'Excluir o projeto "' + p.nome + '"?', confirmText: 'Excluir', danger: true }).then(function (ok) {
      if (!ok) return;
      state.projs = state.projs.filter(function (x) { return x.id !== id; });
      save(); render();
      JC.toast('Projeto excluído.', 'success');
    });
  }

  /* ---------- Cadastro / edição (modal dinâmico) ---------- */
  function openForm(p) {
    p = p || {};
    var editId = p.id || '';
    var emps = getEmployees();
    var funcSel = (p.envolvidos || []).filter(function (e) { return e.tipo === 'funcionario'; }).map(function (e) { return e.nome; });
    var tercSel = (p.envolvidos || []).filter(function (e) { return e.tipo === 'terceiro'; }).map(function (e) { return e.nome; });

    JC.modal.open({
      title: editId ? 'Editar projeto' : 'Novo projeto',
      subtitle: 'Defina os dados, o prazo e quem está envolvido',
      submitText: editId ? 'Salvar alterações' : 'Criar projeto',
      maxWidth: '600px',
      fields: [
        { type: 'section', label: 'Projeto' },
        { id: 'nome', label: 'Nome do projeto', type: 'text', required: true, value: p.nome || '', placeholder: 'Ex: Usina solar — Galpão Industrial' },
        { id: 'cliente', label: 'Cliente', type: 'text', half: true, value: p.cliente || '', placeholder: 'Ex: Indústria Norte' },
        { id: 'setor', label: 'Setor', type: 'select', half: true, value: p.setor || 'Elétrica', options: ['Elétrica', 'Solar', 'Administrativo', 'Comercial'] },
        { id: 'status', label: 'Status', type: 'select', half: true, value: p.status || 'planejamento',
          options: [{ value: 'planejamento', label: 'Planejamento' }, { value: 'andamento', label: 'Em execução' }, { value: 'revisao', label: 'Em revisão' }, { value: 'concluido', label: 'Concluído' }] },
        { id: 'prio', label: 'Prioridade', type: 'select', half: true, value: p.prio || 'media',
          options: [{ value: 'baixa', label: 'Baixa' }, { value: 'media', label: 'Média' }, { value: 'alta', label: 'Alta' }] },
        { id: 'entrega', label: 'Data de entrega', type: 'date', half: true, value: p.entrega || '', hint: 'Em branco = sem prazo.' },
        { id: 'progresso', label: 'Progresso', type: 'range', min: 0, max: 100, step: 5, suffix: '%', value: p.progresso != null ? p.progresso : 0 },

        { type: 'section', label: 'Envolvidos' },
        { id: 'funcs', label: 'Funcionários', type: 'chips', value: funcSel,
          options: emps.map(function (n) { return { value: n, label: n, avatar: { color: colorFor(n), initials: initials(n) } }; }),
          hint: emps.length ? 'Toque para incluir/remover.' : 'Cadastre funcionários para escolher aqui.' },
        { id: 'terceiros', label: 'Terceiros / parceiros', type: 'tags', value: tercSel, placeholder: 'Nome do terceiro / empresa parceira', addText: 'Adicionar' },

        { type: 'section', label: 'Descrição' },
        { id: 'descricao', label: 'Descrição', type: 'textarea', rows: 3, value: p.descricao || '', placeholder: 'Escopo, observações...' }
      ],
      onSubmit: function (vals) {
        var nome = String(vals.nome || '').trim();
        if (!nome) throw new Error('Informe o nome do projeto.');

        var envolvidos = (vals.funcs || []).map(function (n) { return { nome: n, tipo: 'funcionario' }; })
          .concat((vals.terceiros || []).map(function (n) { return { nome: n, tipo: 'terceiro' }; }));

        var prog = Number(vals.progresso || 0);
        var dados = {
          nome: nome,
          cliente: String(vals.cliente || '').trim(),
          setor: vals.setor,
          status: vals.status,
          prio: vals.prio,
          entrega: vals.entrega || '',
          progresso: vals.status === 'concluido' ? 100 : prog,
          descricao: String(vals.descricao || '').trim(),
          envolvidos: envolvidos
        };

        if (editId) {
          var alvo = state.projs.find(function (x) { return x.id === editId; });
          if (alvo) Object.assign(alvo, dados);
        } else {
          dados.id = 'p' + Date.now();
          state.projs.push(dados);
        }
        save(); render();
        JC.toast(editId ? 'Projeto atualizado.' : 'Projeto criado.', 'success');
      }
    });
  }

  /* ---------- Exportar CSV ---------- */
  function exportCSV() {
    var head = ['Projeto', 'Cliente', 'Setor', 'Status', 'Prioridade', 'Entrega', 'Progresso', 'Envolvidos'];
    var lines = [head.join(';')];
    state.projs.filter(passesFilter).forEach(function (p) {
      var env = (p.envolvidos || []).map(function (e) { return e.nome; }).join(', ');
      lines.push([
        '"' + p.nome.replace(/"/g, '""') + '"',
        '"' + (p.cliente || '').replace(/"/g, '""') + '"',
        p.setor, STATUS_LABEL[p.status], PRIO_LABEL[p.prio],
        p.entrega ? fmtDateBR(p.entrega) : 'Sem prazo',
        (p.progresso || 0) + '%',
        '"' + env.replace(/"/g, '""') + '"'
      ].join(';'));
    });
    JC.saveCSV('projetos-' + new Date().toISOString().slice(0, 10) + '.csv', lines);
  }

  /* ---------- Eventos ---------- */
  document.getElementById('pj-busca')?.addEventListener('input', function (e) { state.busca = e.target.value; render(); });
  document.getElementById('pj-setor')?.addEventListener('change', function (e) { state.setor = e.target.value; render(); });
  document.getElementById('pj-prio')?.addEventListener('change', function (e) { state.prio = e.target.value; render(); });
  document.getElementById('pj-add')?.addEventListener('click', function () { openForm(); });
  document.getElementById('pj-export')?.addEventListener('click', exportCSV);

  /* ---------- Init ---------- */
  initDnD();
  render();
})();