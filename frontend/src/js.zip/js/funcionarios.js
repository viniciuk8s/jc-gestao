/* ============================================================
   funcionarios.js — Gestão de Funcionários (RH)
   Estado em localStorage, visões cards/lista, filtros, resumo,
   cadastro/edição/exclusão (modal dinâmico JC.modal com foto e
   dados pessoais) e exportação CSV.
   ============================================================ */
'use strict';

(function () {
  if (!document.getElementById('hr-grid')) return; // só na página de funcionários

  var KEY = 'jc_funcionarios';

  var JC = window.JC;
  // Helpers compartilhados (ver utils.js)
  var esc = JC.esc, fmt = JC.brl, fmtDateBR = JC.fmtDate;
  var initials = JC.initials, colorFor = JC.color;
  var set = JC.setText;

  var state = {
    funcs: load(),
    view: 'grid',     // 'grid' | 'list'
    busca: '',
    dep: 'todos',
    status: 'todos'
  };

  var STATUS_LABEL = { ativo: 'Ativo', ferias: 'Férias', afastado: 'Afastado', inativo: 'Inativo' };
  var FUNCOES = ['Eletricista', 'Técnico em energia solar', 'Engenheiro eletricista', 'Auxiliar técnico', 'Gerente de obras', 'Vendedor', 'Administrativo', 'Financeiro'];

  /* ---------- Persistência ---------- */
  function load() {
    try { var raw = localStorage.getItem(KEY); if (raw) return JSON.parse(raw); } catch (e) {}
    return seed();
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(state.funcs)); } catch (e) {} }
  function seed() {
    var base = [
      { nome: 'Maria Souza',     funcao: 'Engenheira eletricista',   dep: 'Elétrica',       contrato: 'CLT',        admissao: '2023-02-10', salario: 8200, status: 'ativo',    email: 'maria.souza@jcsolar.com',  telefone: '(84) 99999-0001' },
      { nome: 'Carlos Lima',     funcao: 'Técnico em energia solar', dep: 'Solar',          contrato: 'CLT',        admissao: '2024-06-01', salario: 3800, status: 'ativo',    email: 'carlos.lima@jcsolar.com',  telefone: '(84) 99999-0002' },
      { nome: 'João Pedro',      funcao: 'Eletricista',              dep: 'Elétrica',       contrato: 'CLT',        admissao: '2022-09-15', salario: 3200, status: 'ferias',   email: 'joao.pedro@jcsolar.com',   telefone: '(84) 99999-0003' },
      { nome: 'Ana Beatriz',     funcao: 'Vendedora',                dep: 'Comercial',      contrato: 'PJ',         admissao: '2025-01-20', salario: 2800, status: 'ativo',    email: 'ana.beatriz@jcsolar.com',  telefone: '(84) 99999-0004' },
      { nome: 'Rafael Gomes',    funcao: 'Auxiliar técnico',         dep: 'Solar',          contrato: 'Temporário', admissao: '2026-03-05', salario: 1900, status: 'ativo',    email: 'rafael.gomes@jcsolar.com', telefone: '(84) 99999-0005' },
      { nome: 'Patrícia Nunes',  funcao: 'Analista financeiro',      dep: 'Administrativo', contrato: 'CLT',        admissao: '2021-11-02', salario: 4500, status: 'afastado', email: 'patricia.nunes@jcsolar.com', telefone: '(84) 99999-0006' }
    ];
    return base.map(function (f, i) { f.id = 'f' + (Date.now() + i); return f; });
  }

  /* ---------- Filtro ---------- */
  function getFiltered() {
    var q = state.busca.toLowerCase();
    return state.funcs.filter(function (f) {
      if (state.dep !== 'todos' && f.dep !== state.dep) return false;
      if (state.status !== 'todos' && f.status !== state.status) return false;
      if (q && (f.nome + ' ' + f.funcao + ' ' + (f.email || '')).toLowerCase().indexOf(q) === -1) return false;
      return true;
    }).sort(function (a, b) { return a.nome.localeCompare(b.nome, 'pt-BR'); });
  }

  /* ---------- Resumo ---------- */
  function renderSummary() {
    var total = state.funcs.length;
    var ativos = state.funcs.filter(function (f) { return f.status === 'ativo'; }).length;
    var afast = state.funcs.filter(function (f) { return f.status === 'ferias' || f.status === 'afastado'; }).length;
    var folha = state.funcs.reduce(function (s, f) {
      return s + (f.status !== 'inativo' && f.salario ? Number(f.salario) : 0);
    }, 0);
    set('hr-total', total);
    set('hr-ativos', ativos);
    set('hr-afast', afast);
    set('hr-folha', fmt(folha));
  }

  /* ---------- Avatar (foto ou iniciais) ---------- */
  function avatarHTML(f, cls) {
    if (f.foto) {
      return '<div class="' + cls + ' has-photo" style="background-image:url(\'' + f.foto + '\'); background-size: cover;"></div>';
    }
    return '<div class="' + cls + '" style="background:' + colorFor(f.nome) + '">' + esc(initials(f.nome)) + '</div>';
  }

  /* ---------- Render principal ---------- */
  function render() {
    renderSummary();
    var rows = getFiltered();
    var grid = document.getElementById('hr-grid');
    var listWrap = document.getElementById('hr-list');

    if (state.view === 'grid') {
      grid.hidden = false; listWrap.hidden = true;
      renderGrid(rows);
    } else {
      grid.hidden = true; listWrap.hidden = false;
      renderList(rows);
    }
  }

  function emptyHTML(colspan) {
    var inner = '<div class="ico"><i class="bi bi-people"></i></div>' +
      '<p>Nenhum funcionário encontrado.<br>Cadastre um novo colaborador para começar.</p>';
    return colspan
      ? '<tr><td colspan="' + colspan + '"><div class="hr-empty" style="border:none;padding:40px 20px">' + inner + '</div></td></tr>'
      : '<div class="hr-empty">' + inner + '</div>';
  }

  function renderGrid(rows) {
    var grid = document.getElementById('hr-grid');
    if (rows.length === 0) { grid.innerHTML = emptyHTML(); return; }
    grid.innerHTML = rows.map(function (f) {
      return '' +
      '<div class="hr-card">' +
        '<div class="hr-card-top">' +
          avatarHTML(f, 'hr-avatar') +
          '<div class="hr-id">' +
            '<div class="hr-name">' + esc(f.nome) + '</div>' +
            '<div class="hr-role">' + esc(f.funcao) + '</div>' +
          '</div>' +
        '</div>' +
        '<div class="hr-badges">' +
          '<span class="hr-tag">' + esc(f.dep) + '</span>' +
          '<span class="hr-tag">' + esc(f.contrato) + '</span>' +
          '<span class="st ' + f.status + '">' + STATUS_LABEL[f.status] + '</span>' +
        '</div>' +
        '<div class="hr-meta">' +
          '<div class="hr-meta-item"><i class="bi bi-envelope"></i><span>' + esc(f.email || '—') + '</span></div>' +
          '<div class="hr-meta-item"><i class="bi bi-telephone"></i><span>' + esc(f.telefone || '—') + '</span></div>' +
          '<div class="hr-meta-item"><i class="bi bi-calendar3"></i><span>Admissão ' + fmtDateBR(f.admissao) + '</span></div>' +
        '</div>' +
        '<div class="hr-card-foot">' +
          '<div class="hr-salary-wrap"><span class="cap">Salário</span><span class="hr-salary">' + fmt(Number(f.salario || 0)) + '</span></div>' +
          '<div class="hr-card-actions">' +
            '<button class="icon-btn hr-edit" data-id="' + f.id + '" aria-label="Editar"><i class="bi bi-pencil"></i></button>' +
            '<button class="icon-btn danger hr-del" data-id="' + f.id + '" aria-label="Excluir"><i class="bi bi-trash3"></i></button>' +
          '</div>' +
        '</div>' +
      '</div>';
    }).join('');
    bindRowActions(grid);
  }

  function renderList(rows) {
    var tbody = document.getElementById('hr-tbody');
    if (rows.length === 0) { tbody.innerHTML = emptyHTML(8); return; }
    tbody.innerHTML = rows.map(function (f) {
      return '' +
      '<tr>' +
        '<td data-label="Funcionário"><div class="hr-cell-name">' +
          avatarHTML(f, 'hr-avatar') +
          '<div><div class="n">' + esc(f.nome) + '</div><div class="e">' + esc(f.email || '') + '</div></div>' +
        '</div></td>' +
        '<td data-label="Função">' + esc(f.funcao) + '</td>' +
        '<td data-label="Setor"><span class="hr-tag">' + esc(f.dep) + '</span></td>' +
        '<td data-label="Contrato">' + esc(f.contrato) + '</td>' +
        '<td data-label="Admissão">' + fmtDateBR(f.admissao) + '</td>' +
        '<td class="num" data-label="Salário">' + fmt(Number(f.salario || 0)) + '</td>' +
        '<td data-label="Status"><span class="st ' + f.status + '">' + STATUS_LABEL[f.status] + '</span></td>' +
        '<td class="col-act"><div class="hr-card-actions">' +
          '<button class="icon-btn hr-edit" data-id="' + f.id + '" aria-label="Editar"><i class="bi bi-pencil"></i></button>' +
          '<button class="icon-btn danger hr-del" data-id="' + f.id + '" aria-label="Excluir"><i class="bi bi-trash3"></i></button>' +
        '</div></td>' +
      '</tr>';
    }).join('');
    bindRowActions(tbody);
  }

  function bindRowActions(scope) {
    scope.querySelectorAll('.hr-edit').forEach(function (b) {
      b.addEventListener('click', function () {
        var f = state.funcs.find(function (x) { return x.id === b.dataset.id; });
        if (f) openForm(f);
      });
    });
    scope.querySelectorAll('.hr-del').forEach(function (b) {
      b.addEventListener('click', function () { removeFunc(b.dataset.id); });
    });
  }

  /* ---------- Excluir ---------- */
  function removeFunc(id) {
    var f = state.funcs.find(function (x) { return x.id === id; });
    if (!f) return;
    JC.confirm({ message: 'Excluir ' + f.nome + '?', confirmText: 'Excluir', danger: true }).then(function (ok) {
      if (!ok) return;
      state.funcs = state.funcs.filter(function (x) { return x.id !== id; });
      save(); render();
      JC.toast('Funcionário excluído.', 'success');
    });
  }

  /* ---------- Cadastro / edição (modal dinâmico) ---------- */
  function openForm(f) {
    f = f || {};
    var editId = f.id || '';
    var hoje = new Date().toISOString().slice(0, 10);

    JC.modal.open({
      title: editId ? 'Editar funcionário' : 'Novo funcionário',
      subtitle: 'Dados pessoais e profissionais do colaborador',
      submitText: editId ? 'Salvar alterações' : 'Cadastrar funcionário',
      maxWidth: '560px',
      fields: [
        { type: 'section', label: 'Dados pessoais' },
        { id: 'foto', type: 'avatar', label: 'Foto do funcionário', value: f.foto || '' },
        { id: 'nome', label: 'Nome completo', type: 'text', required: true, value: f.nome || '', placeholder: 'Ex: Maria Souza' },
        { id: 'cpf', label: 'CPF', type: 'text', half: true, value: f.cpf || '', placeholder: '000.000.000-00', inputmode: 'numeric' },
        { id: 'nascimento', label: 'Nascimento', type: 'date', half: true, value: f.nascimento || '' },
        { id: 'telefone', label: 'Telefone', type: 'tel', half: true, value: f.telefone || '', placeholder: '(00) 00000-0000', inputmode: 'tel' },
        { id: 'email', label: 'E-mail', type: 'email', half: true, value: f.email || '', placeholder: 'nome@empresa.com' },
        { id: 'endereco', label: 'Endereço', type: 'text', value: f.endereco || '', placeholder: 'Rua, nº, bairro — cidade' },

        { type: 'section', label: 'Dados profissionais' },
        { id: 'funcao', label: 'Função / Cargo', type: 'text', value: f.funcao || '', placeholder: 'Ex: Eletricista', list: FUNCOES },
        { id: 'dep', label: 'Setor', type: 'select', half: true, value: f.dep || 'Elétrica', options: ['Elétrica', 'Solar', 'Administrativo', 'Comercial'] },
        { id: 'contrato', label: 'Contrato', type: 'select', half: true, value: f.contrato || 'CLT', options: ['CLT', 'PJ', 'Temporário'] },
        { id: 'status', label: 'Status', type: 'select', half: true, value: f.status || 'ativo',
          options: [{ value: 'ativo', label: 'Ativo' }, { value: 'ferias', label: 'Férias' }, { value: 'afastado', label: 'Afastado' }, { value: 'inativo', label: 'Inativo' }] },
        { id: 'admissao', label: 'Admissão', type: 'date', half: true, value: f.admissao || hoje },
        { id: 'salario', label: 'Salário (R$)', type: 'number', step: '0.01', min: '0', inputmode: 'decimal', value: f.salario != null ? f.salario : '', placeholder: '0,00' }
      ],
      onReady: function (ctrl) {
        // Máscaras ao vivo (mobile-friendly)
        var cpf = ctrl.input('cpf'), tel = ctrl.input('telefone');
        function dig(v) { return String(v || '').replace(/\D/g, ''); }
        if (cpf) cpf.addEventListener('input', function () {
          var d = dig(cpf.value).slice(0, 11), out = d;
          if (d.length > 9) out = d.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, '$1.$2.$3-$4');
          else if (d.length > 6) out = d.replace(/(\d{3})(\d{3})(\d{1,3})/, '$1.$2.$3');
          else if (d.length > 3) out = d.replace(/(\d{3})(\d{1,3})/, '$1.$2');
          cpf.value = out;
        });
        if (tel) tel.addEventListener('input', function () {
          var d = dig(tel.value).slice(0, 11), out = d;
          if (d.length > 10) out = d.replace(/(\d{2})(\d{5})(\d{1,4})/, '($1) $2-$3');
          else if (d.length > 6) out = d.replace(/(\d{2})(\d{4,5})(\d{0,4})/, '($1) $2-$3');
          else if (d.length > 2) out = d.replace(/(\d{2})(\d{1,5})/, '($1) $2');
          else if (d.length > 0) out = d.replace(/(\d{1,2})/, '($1');
          tel.value = out;
        });
      },
      onSubmit: function (vals) {
        var nome = String(vals.nome || '').trim();
        if (!nome) throw new Error('Informe o nome do funcionário.');
        var salario = parseFloat(String(vals.salario).replace(',', '.'));
        if (String(vals.salario).trim() !== '' && (isNaN(salario) || salario < 0)) throw new Error('Salário inválido.');

        var dados = {
          nome: nome,
          foto: vals.foto || '',
          funcao: String(vals.funcao || '').trim() || 'Não informado',
          dep: vals.dep, contrato: vals.contrato, status: vals.status,
          salario: isNaN(salario) ? 0 : salario,
          admissao: vals.admissao,
          email: String(vals.email || '').trim(),
          telefone: String(vals.telefone || '').trim(),
          cpf: String(vals.cpf || '').trim(),
          nascimento: vals.nascimento || '',
          endereco: String(vals.endereco || '').trim()
        };

        if (editId) {
          var alvo = state.funcs.find(function (x) { return x.id === editId; });
          if (alvo) Object.assign(alvo, dados);
        } else {
          dados.id = 'f' + Date.now();
          state.funcs.push(dados);
        }
        save(); render();
        JC.toast(editId ? 'Funcionário atualizado.' : 'Funcionário cadastrado.', 'success');
      }
    });
  }

  /* ---------- Exportar CSV ---------- */
  function exportCSV() {
    var rows = getFiltered();
    var head = ['Nome', 'Função', 'Setor', 'Contrato', 'Admissão', 'Salário', 'Status', 'Email', 'Telefone', 'CPF', 'Nascimento', 'Endereço'];
    var lines = [head.join(';')];
    rows.forEach(function (f) {
      lines.push([
        '"' + f.nome.replace(/"/g, '""') + '"',
        '"' + f.funcao.replace(/"/g, '""') + '"',
        f.dep, f.contrato, fmtDateBR(f.admissao),
        Number(f.salario || 0).toFixed(2).replace('.', ','),
        STATUS_LABEL[f.status], f.email || '', f.telefone || '',
        f.cpf || '', f.nascimento ? fmtDateBR(f.nascimento) : '',
        '"' + (f.endereco || '').replace(/"/g, '""') + '"'
      ].join(';'));
    });
    JC.saveCSV('funcionarios-' + new Date().toISOString().slice(0, 10) + '.csv', lines);
  }

  /* ---------- Eventos ---------- */
  var busca = document.getElementById('hr-busca');
  if (busca) busca.addEventListener('input', function () { state.busca = busca.value; render(); });

  var dep = document.getElementById('hr-dep');
  if (dep) dep.addEventListener('change', function () { state.dep = dep.value; render(); });

  var stat = document.getElementById('hr-status');
  if (stat) stat.addEventListener('change', function () { state.status = stat.value; render(); });

  var view = document.getElementById('hr-view');
  if (view) {
    view.addEventListener('click', function (e) {
      var btn = e.target.closest('button[data-view]');
      if (!btn) return;
      state.view = btn.dataset.view;
      view.querySelectorAll('button').forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      render();
    });
  }

  var addBtn = document.getElementById('hr-add');
  if (addBtn) addBtn.addEventListener('click', function () { openForm(); });

  var exp = document.getElementById('hr-export');
  if (exp) exp.addEventListener('click', exportCSV);

  /* ---------- Init ---------- */
  render();
})();